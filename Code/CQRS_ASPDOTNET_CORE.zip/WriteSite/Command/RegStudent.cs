﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using WriteSite.Send;
using WriteSite.Students;

namespace WriteSite.Command
{
    public class RegStudent : ICommandS
    {
        private readonly CommandContext _context1;
        public RegStudent(CommandContext commandContext)
        {
            _context1 = commandContext;
        }

        public Student RegisterStudent(string name, string email)
        {
            var newStudent = new Student() { Name = name, Email = email };
            var message = JsonConvert.SerializeObject(newStudent);
            Sender.EventGenerator(message);
            _context1.Students1.Add(newStudent);


            _context1.SaveChanges();

            return newStudent;
        }
    }
}

