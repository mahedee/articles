﻿
using WriteSite.Students;

namespace WriteSite.Command
{
    public interface ICommandS
    {
        Student RegisterStudent(string name, string email);
    }
}
