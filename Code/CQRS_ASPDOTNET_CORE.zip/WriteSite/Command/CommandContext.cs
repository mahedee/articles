﻿using Microsoft.EntityFrameworkCore;
using WriteSite.Students;

namespace WriteSite.Command
{
    public class CommandContext : DbContext
    {
        public CommandContext(DbContextOptions<CommandContext> options) : base(options) { }
        public DbSet<Student> Students1 { get; set; }

    }
}
