﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WriteSite.Command;

using WriteSite.Students;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WriteSite.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WriteStudentController : ControllerBase
    {
        private readonly ICommandS _commands;
        public WriteStudentController(ICommandS commands)
        {

            _commands = commands ?? throw new ArgumentNullException(nameof(commands));


        }

        [HttpPost]
        public void RegisterStudent([FromBody] StudentDto value)
        {

            _commands.RegisterStudent(value.Name, value.Email);

        }
    }
}
