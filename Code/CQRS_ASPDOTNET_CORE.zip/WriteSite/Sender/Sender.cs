﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriteSite.Send
{
    public class Sender
    {
        public static void EventGenerator(string message)
        {

            var factory = new ConnectionFactory() { HostName = "localhost" };

            using (var connection = factory.CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    //channel.QueueDeclare(queue: "student",
                    //            durable: true,
                    //            exclusive: false,
                    //            autoDelete: false,
                    //            arguments: null);

                    ////string message = "Hello World!";
                    //// RegStudentDto newanimal = new ("5", "white");
                    ////  var message = JsonConvert.SerializeObject(newanimal);
                    //// var message = GetMessage(args);
                    //var body = Encoding.UTF8.GetBytes(message);

                    //var properties = channel.CreateBasicProperties();
                    //properties.Persistent = true;

                    //channel.BasicPublish(exchange: "",
                    //                         routingKey: "student",
                    //                         basicProperties: properties,
                    //                         body: body);
                    var body = Encoding.UTF8.GetBytes(message);
                    channel.ExchangeDeclare("studentExchange1", ExchangeType.Direct);
                    channel.QueueDeclare("student1", false, false, false, null);
                    channel.QueueBind("student1", "studentExchange1", "", null);
                    channel.BasicPublish("studentExchange1", "", null, body);
                }
            }


        }
    }
}
