﻿using RabbitMQ.Client;
using System;
using System.Text;
using ReadSite.Students;
using ReadSite.Query;
using RabbitMQ.Client.Events;
using Newtonsoft.Json;
using System.Collections.Generic;

class Receiver
{

    public static List<Student> ReceiveEvent()
    {

        List<Student> students = new List<Student>();
        var factory = new ConnectionFactory() { HostName = "localhost" };
        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            //channel.QueueDeclare(queue: "student", durable: true, exclusive: false, autoDelete: false, arguments: null);
            //channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

            //var consumer = new EventingBasicConsumer(channel);
            //List<Student> students = new List<Student>();
            //consumer.Received += (model, ea) =>
            //{
            //    var body = ea.Body;
            //    var msg = Encoding.UTF8.GetString(body);
            //    //var animal_1 = JsonConvert.DeserializeObject(message);
            //    var updatedStudent = JsonConvert.DeserializeObject<Student>(msg);

            //    if (updatedStudent != null)
            //    {
            //        students.Add(updatedStudent);
            //    }
            //    //UpdateEvent.U
            //    channel.BasicAck(

            //        deliveryTag: ea.DeliveryTag,

            //        multiple: false

            //    );
            //};
            //channel.BasicConsume(queue: "student", autoAck: false, consumer: consumer);

            channel.ExchangeDeclare("studentExchange1", ExchangeType.Direct);
            channel.QueueDeclare("student1", false, false, false, null);
            channel.QueueBind("student1", "studentExchange1", "", null);

            bool noAck = true;
            var response = channel.QueueDeclarePassive("student1");
            for (int i = 0; i < response.MessageCount; i++)
            {
                BasicGetResult result = channel.BasicGet("student1", noAck);
                if (result != null)
                {
                    var body = result.Body;
                    var message = Encoding.UTF8.GetString(body);
                    var student = JsonConvert.DeserializeObject<Student>(message);
                    students.Add(student);
                }
            }
            return students;
        }
    }
}

