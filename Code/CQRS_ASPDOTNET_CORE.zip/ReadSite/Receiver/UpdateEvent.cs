﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReadSite.Students;

namespace ReadSite.Query
{
    public interface IUpdateEvent
    {
        void updatestudent(List<Student> students);
    }
    public class UpdateEvent : IUpdateEvent
    {
        private readonly QueryContext _context1;
        public UpdateEvent(QueryContext commandContext)
        {
            _context1 = commandContext;
        }

        public void updatestudent(List<Student> students)
        {
            foreach (var student in students)
            {
                _context1.Add(student);
            }


            _context1.SaveChanges();
        }
    }
}
