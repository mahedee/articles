﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ReadSite.Query;

namespace ReadSite.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ReadStudentController : ControllerBase
    {
        private readonly IQueries _queries;
        private readonly IUpdateEvent _updateEvent;


        public ReadStudentController(IQueries queries, IUpdateEvent updateEvent)
        {
            _queries = queries ?? throw new ArgumentNullException(nameof(queries));
          
            _updateEvent = updateEvent ?? throw new ArgumentNullException(nameof(updateEvent));

        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> Get()
        {
            var students = Receiver.ReceiveEvent();
            if (students.Count > 0)
            {
                _updateEvent.updatestudent(students);
            }
            return (await _queries.GetAllStudent()).ToList();
        }
    }
}
