﻿using Microsoft.EntityFrameworkCore;
using ReadSite.Students;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReadSite.Query
{
    public class QueryContext : DbContext
    {

        public QueryContext(DbContextOptions<QueryContext> options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
    }
    
}
