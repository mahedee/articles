﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReadSite.Query
{
    public interface IQueries
    {
        Task<IEnumerable<object>> GetAllStudent();


    }
}
