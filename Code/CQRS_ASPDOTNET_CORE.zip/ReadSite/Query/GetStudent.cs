﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ReadSite.Students;

namespace ReadSite.Query
{
    public class GetStudent : IQueries
    {
        private readonly string _connectionString;
        public GetStudent(string connectionString)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentException("message", nameof(connectionString));
            }


            _connectionString = connectionString;

        }
        public async Task<IEnumerable<object>> GetAllStudent()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();


                return await conn.QueryAsync<object>("SELECT * FROM dbo.Students;");
            }
        }
    }

}
